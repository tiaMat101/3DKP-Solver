class Box {
	private:
		vector<Vertex*> vertices;
		float x, y, z;
		float width, height, depth;
		float value;
		float weight;

	public:
		Box(vector<Vertex*> vertices, float value, float weight);
		vector<Vertex*> getVertices() const;
		vec3 getPosition() const;
		vec3 getSize() const;
		void move(float x, float y, float z);
		float getWeight() const;
		float getValue() const;
};