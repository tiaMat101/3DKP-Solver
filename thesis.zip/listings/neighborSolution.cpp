vector<Box*> createInitialSolution(vector<Box*> boxes, int maxWeight, vec3 containerSize) {
	vector<Box*> solution;
	do {
		solution.clear();
		for (Box* box : boxes) {
			if (rand() % 2 == 1)
				solution.push_back(box);
		}
	} while (getWeight(solution) > maxWeight || !fits(solution, containerSize));
	return solution;
}

vector<Box*> createNeighborSolution(vector<Box*> currentSolution, vector<Box*> remainingBoxes) {
	if (currentSolution.size() == 0)
		return { remainingBoxes[rand() % remainingBoxes.size()] };

	vector<Box*> neighbor = currentSolution;
	switch (rand() % 3) {
		case 0:
			neighbor.erase(neighbor.begin() + rand() % neighbor.size());
			break;
		case 1:
			neighbor.push_back(remainingBoxes[rand() % remainingBoxes.size()]);
			break;
		case 2:
			neighbor[rand() % neighbor.size()] = remainingBoxes[rand() % remainingBoxes.size()];
			break;
	}
	return neighbor;
}