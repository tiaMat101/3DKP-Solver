char cwd[1024];
if (_getcwd(cwd, sizeof(cwd)) == nullptr) {
	fprintf(stderr, "ERROR LOADING CURRENT DIRECTORY\n");
	exit(-1);
}
strcat_s(cwd, sizeof(cwd), "\\src\\main\\kp.txt");

ifstream file(cwd);
if (!file) {
	std::cerr << "ERROR LOADING FILE" << endl;
	exit(-1);
}

vec3 containerSize = vec3(0);
int maxWeight;
file >> containerSize.x >> containerSize.y >> containerSize.z;
file >> maxWeight;

vector<Box*> boxes;
int width, height, depth, profit, weight;
float r, g, b;
int i = 1;
while (file >> width >> height >> depth >> profit >> weight >> r >> g >> b) {
	auto bVal = ShapeBuilder::createBox(width, height, depth, vec4(r, g, b, 1));
	Box* shape = new Box(bVal.first, bVal.second, i, profit, weight);
	i++;
	boxes.push_back(shape);
}