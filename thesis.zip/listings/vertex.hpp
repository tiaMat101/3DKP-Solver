class Vertex {
	private:
		vec3 coordinates;
		vec4 color;

	public:
		Vertex(vec3 coordinates, vec4 color);
		vec3 getCoordinates() const;
		void setCoordinates(vec3 coordinates);
		vec4 getColor() const;
};