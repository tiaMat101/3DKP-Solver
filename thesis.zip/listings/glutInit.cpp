void GlutManager::openWindow(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitContextVersion(4, 0);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(APP_WIDTH, APP_HEIGHT);
	glutInitWindowPosition(50, 50);
	glutCreateWindow(APP_NAME);

	glutDisplayFunc(drawSceneAccessor);
	glutKeyboardFunc(movementAccessor);
	glutMouseWheelFunc(zoomAccessor);
	glutPassiveMotionFunc(lookAroundAccessor);
	glutTimerFunc(FRAME_LENGTH, update, 0);

	glewExperimental = GL_TRUE;
	glewInit();
	GLuint programId = createProgram(
		(char*)"\\src\\shaderFiles\\vertexShader.glsl",
		(char*)"\\src\\shaderFiles\\fragmentShader.glsl"
	);

	for (Box* shape : this->boxes)
		shape->init();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	this->projectionMatrixUniform = glGetUniformLocation(programId, "projection");
	this->modelMatrixUniform = glGetUniformLocation(programId, "model");
	this->viewMatrixUniform = glGetUniformLocation(programId, "view");
	this->viewPositionUniform = glGetUniformLocation(programId, "viewPos");

	glutMainLoop();
}