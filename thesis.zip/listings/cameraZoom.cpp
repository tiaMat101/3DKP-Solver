void GlutManager::zoomCamera(int wheel, int direction, int x, int y) {
	instance->camera->getPerspective()->zoom(CAMERA_ZOOM * -direction);
}

void Perspective::zoom(float zoom) {
	this->fov += zoom;

	if (this->fov < 1.0f)
		this->fov = 1.0f;
	if (this->fov > 120.0f)
		this->fov = 120.0f;
}