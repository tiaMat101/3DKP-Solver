class GlutManager {
	private:
		static GlutManager* instance;

		GLuint programId;
		unsigned int projectionMatrixUniform;
		unsigned int viewMatrixUniform;
		unsigned int modelMatrixUniform;
		unsigned int viewPositionUniform;
		mat4 projectionMatrix;
		mat4 viewMatrix;
		vector<Box*> boxes;
		Camera* camera;
		ShadersManager* shadersManager;
		bool insert;
		bool pause;

		static void drawScene(void);
		static void moveCamera(unsigned char key, int x, int y);
		static void zoomCamera(int wheel, int direction, int x, int y);
		static void lookAround(int x, int z);
		static void update(int value);

	public:
		GlutManager(vector<Box*> boxes);
		void openWindow(int argc, char** argv);
};