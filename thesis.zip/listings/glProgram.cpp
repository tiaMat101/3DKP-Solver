GLuint createProgram(char* vertexShaderFile char* fragmentShaderFile) {
	int success;
	char infoLog[512];
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	GLchar* vertexShader = readShaderSource(vertexShaderFile);
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShaderId, 1, (const char**)&vertexShader, NULL);
	glCompileShader(vertexShaderId);

	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		fprintf(stderr, "ERROR - VERTEX SHADER COMPILATION FAILED\n %s \n", infoLog);
	}

	GLchar* fragmentShader = readShaderSource(fragmentShaderFile);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShaderId, 1, (const char**)&fragmentShader, NULL);
	glCompileShader(fragmentShaderId);

	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(fragmentShaderId, 512, NULL, infoLog);
		fprintf(stderr, "ERROR - FRAGMENT SHADER COMPILATION FAILED\n %s \n", infoLog);
	}

	GLuint programId = glCreateProgram();
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);
	glLinkProgram(programId);

	return programId;
}