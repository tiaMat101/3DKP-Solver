class Box {
	private:
		GLuint VAO;
		GLuint verticesVBO;
		GLuint colorsVBO;
		GLuint EBO;
		mat4 model;
		vector<Vertex*> vertices;
		vector<GLuint> indices;
		int id;
		float x, y, z;
		float xTarget, yTarget, zTarget;
		float xStart, yStart, zStart;
		float width, height, depth;
		float value;
		float weight;
		vec4 anchorWorld;
		vec4 anchorObj;

	public:
		Box(vector<Vertex*> vertices, vector<GLuint> indices, int id, float value, float weight);
		int getId() const;
		GLuint* getVAO();
		GLuint* getVerticesVBO();
		GLuint* getColorsVBO();
		GLuint* getEBO();
		vector<Vertex*> getVertices() const;
		vector<vec3> getVerticesCoordinates() const;
		vector<vec4> getVerticesColors() const;
		vector<GLuint> getIndices() const;
		mat4 getModel() const;
		void setModel(mat4 model);
		vec3 getPosition() const;
		void setPosition(vec3 position);
		vec3 getSize() const;
		void move(float x, float y, float z);
		float getWeight() const;
		float getValue() const;
		void init();
		bool targetReached() const;
		void moveTowardsTarget();
		bool startReached() const;
		void moveTowardsStart();
};