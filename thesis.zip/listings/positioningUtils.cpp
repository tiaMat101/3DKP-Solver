static bool collides(vector<Box*> placedBoxes, Box* box, vec3 boxPosition, vec3 containerSize) {
	for (Box* placedBox : placedBoxes) {
		vec3 pbPos = placedBox->getPosition();
		vec3 pbSize = placedBox->getSize();
		bool xCheck = pbPos.x + pbSize.x <= boxPosition.x || boxPosition.x + box->getSize().x <= pbPos.x;
		bool yCheck = pbPos.y + pbSize.y <= boxPosition.y || boxPosition.y + box->getSize().y <= pbPos.y;
		bool zCheck = pbPos.z + pbSize.z <= boxPosition.z || boxPosition.z + box->getSize().z <= pbPos.z;
		bool collision = !(xCheck || yCheck || zCheck);
		if (collision || boxPosition.x + box->getSize().x > containerSize.x || boxPosition.y + box->getSize().y > containerSize.y || boxPosition.z + box->getSize().z > containerSize.z)
			return true;
	}
	return false;
}

bool isFlying(vector<Box*> placedBoxes, Box* box, vec3 position) {
	if (position.y == 0)
		return false;
	vec3 size = box->getSize();
	vec3 midPoint = vec3(position.x + size.x / 2, position.y, position.z + size.z / 2);
	for (Box* placedBox : placedBoxes) {
		vec3 pbPos = placedBox->getPosition();
		vec3 pbSize = placedBox->getSize();
		if (pbPos.y + pbSize.y == midPoint.y
			&& pbPos.x <= midPoint.x && midPoint.x <= pbPos.x + pbSize.x
			&& pbPos.z <= midPoint.z && midPoint.z <= pbPos.z + pbSize.z) {
			return false;
		}
	}
	return true;
}