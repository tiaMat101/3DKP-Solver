int getWeight(vector<Box*> boxes) {
	int weight = 0;
	for (Box* box : boxes)
		weight += box->getWeight();
	return weight;
}

int getProfit(vector<Box*> boxes) {
	int profit = 0;
	for (Box* box : boxes)
		profit += box->getValue();
	return profit;
}

vector<Box*> getDifference(vector<Box*> v1, vector<Box*> v2) {
	sort(v1.begin(), v1.end());
	sort(v2.begin(), v2.end());
	vector<Box*> diff;
	set_difference(v1.begin(), v1.end(), v2.begin(), v2.end(), back_inserter(diff));
	return diff;
}