vec3 getCoordinates(vector<Box*> placedBoxes, Box* box, vec3 containerSize) {
	if (placedBoxes.size() == 0)
		return vec3(0);

	vector<vec3> positions = getAvailablePositions(placedBoxes, box, containerSize);
	if (positions.size() == 0)
		return vec3(-1);

	// Sort by depth
	sort(positions.begin(), positions.end(), [](vec3 a, vec3 b) { return a.z < b.z; });
	map<int, vector<vec3>> coordinatesMap;
	for (vec3 position : positions)
		coordinatesMap[position.z].push_back(position);

	vector<vec3> bottomPositions = coordinatesMap[positions[0].z];
	coordinatesMap = {};
	if (bottomPositions.size() == 1)
		return bottomPositions[0];

	// Sort by vertical position
	sort(bottomPositions.begin(), bottomPositions.end(), [](vec3 a, vec3 b) { return a.y < b.y; });
	for (vec3 position : bottomPositions)
		coordinatesMap[position.y].push_back(position);
	vector<vec3> backPositions = coordinatesMap[bottomPositions[0].y];
	coordinatesMap = {};
	if (backPositions.size() == 1)
		return backPositions[0];

	// Sort by horizontal position
	sort(backPositions.begin(), backPositions.end(), [](vec3 a, vec3 b) { return a.x < b.x; });
	for (vec3 position : backPositions)
		coordinatesMap[position.x].push_back(position);
	vector<vec3> leftPositions = coordinatesMap[backPositions[0].x];
	return leftPositions[0];
}