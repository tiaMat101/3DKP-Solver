void GlutManager::drawScene(void) {
	this->projectionMatrix = perspective(
		radians(this->camera->getPerspective()->getFOV()),
		this->camera->getPerspective()->getAspectRatio(),
		this->camera->getPerspective()->getNearPlane(),
		this->camera->getPerspective()->getFarPlane()
	);
	this->viewMatrix = lookAt(
		vec3(this->camera->getView()->getPosition()),
		vec3(this->camera->getView()->getTarget()),
		vec3(this->camera->getView()->getUpvector())
	);

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Background Color
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glUseProgram(this->shadersManager->getProgramId());
	glUniformMatrix4fv(this->projectionMatrixUniform, 1, GL_FALSE, value_ptr(this->projectionMatrix));
	glUniformMatrix4fv(this->viewMatrixUniform, 1, GL_FALSE, value_ptr(this->viewMatrix));
	glPointSize(10.0f);

	Box* container = this->boxes[0];
	glUniformMatrix4fv(this->modelMatrixUniform, 1, GL_FALSE, value_ptr(container->getModel()));
	glBindVertexArray(*container->getVAO());
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glDrawElements(GL_LINES, (container->getIndices().size()) * sizeof(GLuint), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	for (int i = 1; i < this->boxes.size(); i++) {
		Box* box = this->boxes[i];
		glUniformMatrix4fv(this->modelMatrixUniform, 1, GL_FALSE, value_ptr(box->getModel()));
		glBindVertexArray(*box->getVAO());
		glPolygonMode(GL_FRONT_AND_BACK, this->polygonMode);
		glDrawElements(this->elementsMode, (box->getIndices().size()) * sizeof(GLuint), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
	}
	glutSwapBuffers();
}