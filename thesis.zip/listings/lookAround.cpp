void GlutManager::lookAround(int x, int y) {
	// Initialization
	static int mouseX = x;	
	static int mouseY = y;
	static float theta = -90.0f;
	static float phi = 0.0f;

	float centerX = APP_WIDTH / 2.0f;
	float centerY = APP_HEIGHT / 2.0f;
	mouseX = x;
	mouseY = y;

	float xoffset = (x - centerX) * 0.05f;
	float yoffset = (APP_HEIGHT - y - centerY) * 0.05f;
	theta += xoffset;
	phi += yoffset;

	if (phi > 90.0f) phi = 90.0f;
	if (phi < -90.0f) phi = -90.0f;
	vec3 front = vec3(
		cos(radians(theta)) * cos(radians(phi)),
		sin(radians(phi)),
		sin(radians(theta)) * cos(radians(phi))
	);
	vec4 position = instance->camera->getView()->getPosition();
	vec4 direction = vec4(normalize(front), 0.0f);
	instance->camera->getView()->setTarget(vec3(position + direction));

	// Keep cursor on the center of the window
	glutWarpPointer(centerX, centerY);
}