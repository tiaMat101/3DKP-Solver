char* readShaderSource(char* shaderFile) {
	char cwd[1024];
    if (_getcwd(cwd, sizeof(cwd)) == nullptr) {
        fprintf(stderr, "ERROR - LOADING CURRENT DIRECTORY FAILED\n");
        exit(-1);
    }
    strcat_s(cwd, sizeof(cwd), shaderFile);
    FILE* file;
    errno_t err = fopen_s(&file, cwd, "rb");
    if (err != 0 || file == nullptr) {
        fprintf(stderr, "ERROR %d - FILE LOADING FAILED (%s)\n", err, cwd);
        exit(-1);
    }
    if (fseek(file, 0L, SEEK_END) != 0) {
        fprintf(stderr, "ERROR - SEEKING END OF FILE FAILED (%s)\n", cwd);
        fclose(file);
        exit(-1);
    }
    long size = ftell(file);
    if (size == -1L) {
        fprintf(stderr, "ERROR - FILE SIZE (%s)\n", cwd);
        fclose(file);
        exit(-1);
    }
    if (fseek(file, 0L, SEEK_SET) != 0) {
        fprintf(stderr, "ERROR - SEEKING START OF FILE FAILED (%s)\n", cwd);
        fclose(file);
        exit(-1);
    }
    char* buf = new(std::nothrow) char[size + 1];
    if (buf == nullptr) {
        fprintf(stderr, "ERROR - ALLOCATING FRAME BUFFER FAILED (%s)\n", cwd);
        fclose(file);
        exit(-1);
    }
    size_t bytesRead = fread(buf, 1, size, file);
    if (bytesRead != size) {
        fprintf(stderr, "ERROR - READING FILE FAILED (%s)\n", cwd);
        delete[] buf;
        fclose(file);
        exit(-1);
    }
    buf[size] = '\0';
    fclose(file);
    return buf;
}