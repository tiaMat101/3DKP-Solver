pair<vector<Vertex*>, vector<GLuint>> createBox(float width, float height, float depth, vec4 color) {
    float x = width;
    float y = height;
    float z = depth;

    vector<Vertex* > vertices;

    // Front
    vertices.push_back(new Vertex(vec3(0, y, z), color));
    vertices.push_back(new Vertex(vec3(x, y, z), color));
    vertices.push_back(new Vertex(vec3(x, 0, z), color));
    vertices.push_back(new Vertex(vec3(0, 0, z), color));

    // Back
    vertices.push_back(new Vertex(vec3(0, y, 0), color));
    vertices.push_back(new Vertex(vec3(x, y, 0), color));
    vertices.push_back(new Vertex(vec3(x, 0, 0), color));
    vertices.push_back(new Vertex(vec3(0, 0, 0), color));

    // Indexes
    vector<GLuint> indices = {
        // Front Face
        0, 1, 2, 2, 3, 0,
        // Right Face
        1, 5, 6, 6, 2, 1,
        // Back Face
        7, 6, 5, 5, 4, 7,
        // Left Face
        4, 0, 3, 3, 7, 4,
        // Top Face
        4, 5, 1, 1, 0, 4,
        // Bottom Face
        3, 2, 6, 6, 7, 3
    };
    return { vertices, indices };
}