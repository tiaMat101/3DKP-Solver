void initBox(Box* box) {
    glGenVertexArrays(1, box->getVAO());
    glBindVertexArray(*box->getVAO());

    glGenBuffers(1, box->getVerticesVBO());
    glBindBuffer(GL_ARRAY_BUFFER, *box->getVerticesVBO());
    glBufferData(
        GL_ARRAY_BUFFER,
        box->getVerticesCoordinates().size() * sizeof(vec3),
        box->getVerticesCoordinates().data(),
        GL_STATIC_DRAW
    );
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);

    glGenBuffers(1, box->getColorsVBO());
    glBindBuffer(GL_ARRAY_BUFFER, *box->getColorsVBO());
    glBufferData(
        GL_ARRAY_BUFFER,
        box->getVerticesColors().size() * sizeof(vec4),
        box->getVerticesColors().data(),
        GL_STATIC_DRAW
    );
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(1);

    glGenBuffers(1, box->getEBO());
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, *box->getEBO());
    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        box->getIndices().size() * sizeof(GLuint),
        box->getIndices().data(),
        GL_STATIC_DRAW
    );
}