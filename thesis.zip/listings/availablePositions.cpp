vector<vec3> getAvailablePositions(vector<Box*> placedBoxes, Box* box, vec3 containerSize) {
	vector<vec3> positions;
	for (Box* placedBox : placedBoxes) {
		int xi = placedBox->getPosition().x;
		int xRight = xi + placedBox->getSize().x;
		int yi = placedBox->getPosition().y;
		int yUp = yi + placedBox->getSize().y;
		int zi = placedBox->getPosition().z;
		int zFront = zi + placedBox->getSize().z;
		if (!collides(placedBoxes, box, vec3(xRight, yi, zi), containerSize) && !isFlying(placedBoxes, box, vec3(xRight, yi, zi)))
			positions.push_back(vec3(xRight, yi, zi));
		if (!collides(placedBoxes, box, vec3(xi, yUp, zi), containerSize) && !isFlying(placedBoxes, box, vec3(xRight, yi, zi)))
			positions.push_back(vec3(xi, yUp, zi));
		if (!collides(placedBoxes, box, vec3(xi, yi, zFront), containerSize) && !isFlying(placedBoxes, box, vec3(xi, yi, zFront)))
			positions.push_back(vec3(xi, yi, zFront));
	}
	int xValues[] = { 0, getMaxX(placedBoxes, box, containerSize) };
	int yValues[] = { 0, getMaxY(placedBoxes, box, containerSize) };
	int zValues[] = { 0, getMaxZ(placedBoxes, box, containerSize) };
	for (int j = 0; j < 2; ++j) {
		for (int k = 0; k < 2; ++k) {
			for (int l = 0; l < 2; ++l) {
				int x = xValues[j];
				int y = yValues[k];
				int z = zValues[l];
				if (!collides(placedBoxes, box, vec3(x, y, z), containerSize) && !isFlying(placedBoxes, box, vec3(x, y, z)))
					positions.push_back(vec3(x, y, z));
			}
		}
	}
	return positions;
}