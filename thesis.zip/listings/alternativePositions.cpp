int getMaxX(vector<Box*> placedBoxes, Box* box, vec3 containerSize) {
	vector<Box*> px;
	std::copy_if(placedBoxes.begin(), placedBoxes.end(), std::back_inserter(px), [&containerSize](Box* pBox) {
		return pBox->getPosition().x + pBox->getSize().x <= containerSize.x - pBox->getSize().x;
	});
	int maxX = 0;
	for (int i = 0; i < px.size(); i++) {
		int x = px[i]->getPosition().x + px[i]->getSize().x;
		if (x > maxX)
			maxX = x;
	}
	return maxX;
}

int getMaxY(vector<Box*> placedBoxes, Box* box, vec3 containerSize) {
	vector<Box*> py;
	std::copy_if(placedBoxes.begin(), placedBoxes.end(), std::back_inserter(py), [&containerSize](Box* pBox) {
		return pBox->getPosition().y + pBox->getSize().y <= containerSize.y - pBox->getSize().y;
	});
	int maxY = 0;
	for (int i = 0; i < py.size(); i++) {
		int y = py[i]->getPosition().y + py[i]->getSize().y;
		if (y > maxY)
			maxY = y;
	}
	return maxY;
}

int getMaxZ(vector<Box*> placedBoxes, Box* box, vec3 containerSize) {
	vector<Box*> pz;
	std::copy_if(placedBoxes.begin(), placedBoxes.end(), std::back_inserter(pz), [&containerSize](Box* pBox) {
		return pBox->getPosition().z + pBox->getSize().z <= containerSize.z - pBox->getSize().z;
	});
	int maxZ = 0;
	for (int i = 0; i < pz.size(); i++) {
		int z = pz[i]->getPosition().z + pz[i]->getSize().z;
		if (z > maxZ)
			maxZ = z;
	}
	return maxZ;
}