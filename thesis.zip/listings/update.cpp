void GlutManager::update(int value) {
	if (!instance->pause) {
		if (instance->insert) {
			for (int i = 0; i < instance->boxes.size(); i++) {
				if (!instance->boxes[i]->targetReached()) {
					instance->boxes[i]->moveTowardsTarget();
					break;
				}
			}
		} else {
			for (int i = instance->boxes.size() - 1; i >= 0; i--) {
				if (!instance->boxes[i]->startReached()) {
					instance->boxes[i]->moveTowardsStart();
					break;
				}
			}
		}
	}
	glutTimerFunc(FRAME_LENGTH, update, 0);
	glutPostRedisplay();
}

bool Box::targetReached() const {
	return abs(this->xTarget - this->x) <= 0.001 && abs(this->yTarget - this->y) <= 0.001 && abs(this->zTarget - this->z) <= 0.001;
}

void Box::moveTowardsTarget() {
	float xStep = (this->xTarget - this->xStart) / (FRAME_LENGTH * 3);
	float yStep = (this->yTarget - this->yStart) / (FRAME_LENGTH * 3);
	float zStep = (this->zTarget - this->zStart) / (FRAME_LENGTH * 3);
	this->move(xStep, yStep, zStep);
}

bool Box::startReached() const {
	return abs(this->xStart - this->x) <= 0.001 && abs(this->yStart - this->y) <= 0.001 && abs(this->zStart - this->z) <= 0.001;
}

void Box::moveTowardsStart() {
	float xStep = (this->xStart - this->xTarget) / (FRAME_LENGTH * 3);
	float yStep = (this->yStart - this->yTarget) / (FRAME_LENGTH * 3);
	float zStep = (this->zStart - this->zTarget) / (FRAME_LENGTH * 3);
	this->move(xStep, yStep, zStep);
}