void GlutManager::moveCamera(unsigned char key, int x, int y) {
	vec4 direction = instance->camera->getView()->getDirection();
	vec4 upVector = instance->camera->getView()->getUpvector();

	vec3 horizontalMovement = cross(vec3(direction), vec3(upVector)) * CAMERA_SPEED;
	vec3 verticalMovement = upVector * CAMERA_SPEED;
	vec3 depthMovement = vec3(direction) * CAMERA_SPEED;

	switch (key)
	{
		case 'a': case 'A': // Left
			instance->camera->getView()->move(vec4(-horizontalMovement, 1.0f));
			break;
		case 'd': case 'D': // Right
			instance->camera->getView()->move(vec4(horizontalMovement, 1.0f));
			break;
		case 'e': case 'E': // Up
			instance->camera->getView()->move(vec4(verticalMovement, 1.0f));
			break;
		case 'q': case 'Q': // Down
			instance->camera->getView()->move(vec4(-verticalMovement, 1.0f));
			break;
		case 'w': case 'W': // Forward
			instance->camera->getView()->move(vec4(depthMovement, 1.0f));
			break;
		case 's': case 'S': // Backward
			instance->camera->getView()->move(vec4(-depthMovement, 1.0f));
			break;
		case 'p': case 'P':	// Pause/Unpause
			instance->pause = !instance->pause;
			break;
		case 'c': case 'C':	// Start placing in the container
			instance->pause = false;
			instance->insert = true;
			break;
		case 'b': case 'B':	// Start removing from the container
			instance->pause = false;
			instance->insert = false;
			break;
		case 27:			// Exit
			glutLeaveMainLoop();
			break;
		default:
			break;
	}
}