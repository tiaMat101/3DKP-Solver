srand(time(NULL));
KnapsackSolver* ks = new KnapsackSolver(containerSize, maxWeight);

auto start = std::chrono::high_resolution_clock::now();
vector<pair<Box*, vec3>> solution = ks->solve3D(boxes);
auto end = std::chrono::high_resolution_clock::now();

chrono::duration<double> elapsed = end - start;
cout << "Elapsed Time: " << elapsed.count() << " seconds" << endl;

vector<Box*> scene;
auto containerValues = ShapeBuilder::createBox(containerSize.x, containerSize.y, containerSize.z, vec4(1.0f));
Box* container = new Box(containerValues.first, containerValues.second, 0, 0.0f, 0.0f);
scene.push_back(container);

cout << "Boxes: ";
int totalProfit = 0, totalWeight = 0;
for (pair<Box*, vec3> box : solution) {
	cout << box.first->getId() << " ";
	totalProfit += box.first->getValue();
	totalWeight += box.first->getWeight();

	box.first->setPosition(box.second);
	box.first->setTarget(box.second);
	box.first->setStartPosition(vec3(box.second.x, box.second.y, rand() % 20 + 10));
	scene.push_back(box.first);
}
cout << "\nProfit: " << totalProfit << "\tWeight: " << totalWeight << "/" << maxWeight << endl;

GlutManager* glutManager = new GlutManager(scene);
glutManager->openWindow(argc, argv);