vector<vec3> getBoxesCoordinates(vector<Box*> boxes) {
	vector<vec3> coords;
	for (Box* box : boxes)
		coords.push_back(box->getPosition());
	return coords;
}

vector<pair<Box*, vec3>> createSolutionFromBoxes(vector<Box*> boxes) {
	vector<pair<Box*, vec3>> solution;
	for (Box* box : boxes)
		solution.push_back({ box, box->getPosition() });
	return solution;
}